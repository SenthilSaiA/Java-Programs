package few;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a=new String("Java");
		String b=new String("Java");
		if(a==b)
			System.out.println("equal");
		else
			System.out.println("not equal");

	}

}//because it is stored in different space if you not use NEW then it will print equals
