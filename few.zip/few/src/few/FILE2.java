package few;
import java.io.*;
import java.util.*;
public class FILE2 {
public static void main(String args[]) {
	String filepath="ouput.txt";
	try {
		File file=new File(filepath);
		if(!file.exists()) {
			file.createNewFile();
			System.out.println("created successfully");
		}
		else {
				System.out.println("file already exist");
				
			}
	FileOutputStream a=new FileOutputStream(file);
	Scanner s=new Scanner(System.in);
	System.out.println("enter the text");
	while(s.hasNextLine()) {
		String b=s.nextLine();
		if(b.equalsIgnoreCase("exit")) {
			break;
		}
		byte[] c=b.getBytes();
		a.write(c);
		a.write("\n".getBytes());
	}
	a.close();
	System.out.println("data is written successfully");
		}
	catch(IOException e) {
		System.out.println("err in file creation" +e.getMessage());
		e.printStackTrace();
	}
	
}
}
