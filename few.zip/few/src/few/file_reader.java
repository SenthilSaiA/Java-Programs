package few;
import java.io.IOException;
import java.io.FileReader;
import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
public class file_reader {

	public static void main(String[] args) {
		try {
		String filepath = "E:\\FITA\\few\\thanks";
		File c=new File(filepath+ ".txt");
		FileReader u=new FileReader(c);
		Scanner p=new Scanner(u);
		while(p.hasNextLine()) {
			String n=p.nextLine();
			System.out.println(n + " ");
		}
			u.close();
		}
		catch(IOException e) {
			System.out.println("an error occured " +e.getMessage());
			
		}

	}

}
