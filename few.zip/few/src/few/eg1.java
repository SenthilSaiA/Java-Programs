package few;
import java.util.Scanner;
public class eg1 {

	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		
		
	}
}
