package few;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;

public class Read_file2 {

	public static void main(String[] args) throws Exception {
		File a = new File("E:\\FITA\\few\\greeting.txt");
		try (BufferedReader b = new BufferedReader(new FileReader(a))) {
			String line;
			while ((line = b.readLine()) != null) {
				System.out.println(line);
			}
		}
	}

}
