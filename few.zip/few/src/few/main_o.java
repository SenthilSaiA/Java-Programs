package few;

public class main_o {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[]= {120,200,016};
		for(int i=0;i<x.length;i++) {
			System.out.println(x[i]+ "");
		}

	}

}
