package few;
import java.util.*;
public class pattern2 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the String");
		String a = s.next();
		String[] b = a.split("");
		int d = b.length;
		String c = "";
		for (int i = 0; i < d; i++) {
			c = c + b[i];
			System.out.println(c);
			// i=i+1;
		}
		c = "";
		for (int j = d - 1; j >= 0; j--) {
			for(int k=0;k<=j;k++) {
					c=c+b[k];
		}
			System.out.println(c);
	}
		
}
}
