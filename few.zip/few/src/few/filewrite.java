package few;
import java.io.FileWriter;
import java.io.IOException;
public class filewrite {
	public static void main(String args[]) {
		try {
			FileWriter a=new FileWriter("filewrite.txt");
			a.write("sai is bad boy");
			a.close();
			System.out.println("Successfully created");
		}
		catch(IOException e) {
			System.out.println("an error occured");
			e.printStackTrace();
		}
	}

}
