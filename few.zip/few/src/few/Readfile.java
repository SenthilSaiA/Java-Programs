package few;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Readfile {
public static void main(String args[]) {
	try {
		File a=new File("filewrite.txt");
		Scanner s=new Scanner(a);
		while(s.hasNextLine()) {
			String b=s.nextLine();
			System.out.println(b);
		}
		s.close();
	}
	catch(FileNotFoundException e) {
		System.out.println("an error occured" +e.getMessage());
		e.printStackTrace();
	}
}
}
