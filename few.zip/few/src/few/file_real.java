package few;
import java.util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.File.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
public class file_real {
public static void main(String args[]) {
	Scanner s=new Scanner(System.in);
	System.out.println("enter the file name");
	String a=s.next();//input of file name
	String b=a;// file created
	File c=new File(a+ ".txt");//location
	try {
		boolean created=c.createNewFile();
		if(created) {
			System.out.println("file created successfully");
		}
		else {
			System.out.println("file not created ");
		}
		FileWriter d=new FileWriter(c);
		System.out.println("enter the aadhar number:");
		String f=s.next();
		d.write("aadhar number: "  + f);
		System.out.println("enter your aadhar name:");
		String r=s.next();
		d.write("aadhar name:" +r );
		System.out.println("enter your date of birth:");
		String w=s.next();
		d.write("date of birth " +w);
		System.out.println("enter your phno:");
		String j=s.next();
		d.write("your phno:" +j );
		System.out.println("enter your address:");
		String k=s.next();
		d.write("your address:" +k );
		d.close();
		System.out.println("written successfully");
}
	catch(IOException e) {
		System.out.println("an err occured" +e.getMessage());
		e.printStackTrace();
	}
}
}
