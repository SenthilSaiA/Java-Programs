package few;

import java.time.*;
public class date {
	public static void main(String args[]) {
		LocalDate a=LocalDate.now();
		LocalTime b=LocalTime.now();
		System.out.println(a);
		System.out.println(b);
	}

}
