package few;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class space_file {

	public static void main(String[] args) {
		try {
			FileWriter a=new FileWriter("greeting.txt");
			BufferedWriter b=new BufferedWriter(a);
			for(int i=1;i<6;i++) {
				b.write("hello");
				b.newLine();
				b.write("reacher");
				b.newLine();
			}
			b.close();
			System.out.println("written successfully");
		}
		catch (IOException e) {
			System.out.println("an error occured:" +e.getMessage());
		}

	}

}
